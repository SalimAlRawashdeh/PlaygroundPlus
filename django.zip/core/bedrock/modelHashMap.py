modelIDs = {
    "Llama 3": "meta.llama3-70b-instruct-v1:0",
    "Titan Lite": "amazon.titan-text-lite-v1",
    "Claude": "anthropic.claude-v2",
    "DeepSeek": "arn:aws:bedrock:us-west-2:952029066932:inference-profile/us.deepseek.r1-v1:0"
}